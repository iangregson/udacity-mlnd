
# Machine Learning Engineer Nanodegree
## Capstone Project
Ian Gregson
September 22nd 2018

# 1. Definition

### Project Overview

### Problem Statement

### Metrics


```python
from sklearn.metrics import f1_score, make_scorer
f1_scorer = make_scorer(f1_score)
```

## 2. Analysis

### Data Exploration


```python
import pandas as pd
raw_data = pd.read_csv('data/csv/raw_data.csv', low_memory=False)
```


```python
display(raw_data.info())
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 33338 entries, 0 to 33337
    Data columns (total 58 columns):
    Account_Region__c                             25312 non-null object
    Account_Theater__c                            10070 non-null object
    ACV__c                                        33338 non-null float64
    C_Contact_has_accepted_a_follow_on_step__c    33338 non-null bool
    Consulting_Services_Amount__c                 33338 non-null float64
    Created_by_Role__c                            33338 non-null object
    Deal_Type__c                                  781 non-null object
    Decision_Process__c                           0 non-null float64
    Delivery_Type__c                              2 non-null object
    Deployment_timeframe__c                       11 non-null object
    Difference_between_Created_and_Modified__c    33338 non-null float64
    DM_Close_Type__c                              33338 non-null object
    DM_Opp_Age__c                                 33338 non-null float64
    DM_Playbook_Stage__c                          22767 non-null object
    DM_Playbook_Status__c                         33338 non-null object
    Engagement_Mode__c                            18933 non-null object
    Exchange_Reuse_Mgr__c                         33338 non-null bool
    Follow_on_Meeting_Completed__c                33338 non-null bool
    Follow_on_meeting_scheduled__c                33338 non-null bool
    forecast__c                                   31570 non-null object
    ForecastCategory                              33338 non-null object
    HasOpportunityLineItem                        33338 non-null bool
    Inbound__c                                    33338 non-null bool
    Inbound_Source__c                             0 non-null float64
    IsClosed                                      33338 non-null bool
    IsSplit                                       33338 non-null bool
    IsWon                                         33338 non-null bool
    Key_Account__c                                33338 non-null bool
    Large_Deal__c                                 33338 non-null bool
    Lead_Passed_By_Group__c                       14124 non-null object
    Lead_Passed_By_Name__c                        14823 non-null object
    Lead_Passed_By_Role__c                        14803 non-null object
    LeadSource                                    18209 non-null object
    Lead_Source_Asset__c                          14519 non-null object
    Lead_Source_Detail__c                         14832 non-null object
    Lead_Type__c                                  33296 non-null object
    Metric_Accept2Close__c                        33338 non-null float64
    Metric_Create2Close__c                        33338 non-null float64
    M_Is_decision_maker_mobilizer_champ__c        33338 non-null bool
    N_Contact_has_bus_tech_goal_to_address__c     33338 non-null bool
    New_and_Add_On_Subscription__c                27886 non-null float64
    New_Business_Subscription__c                  14184 non-null float64
    Number_of_Products__c                         33338 non-null float64
    OA_Project_Prefix__c                          33338 non-null object
    Opportunity_Classification__c                 18682 non-null object
    Opportunity_Contact_Roles__c                  26576 non-null float64
    Opportunity_Source__c                         32330 non-null object
    Sales_Channel__c                              31384 non-null object
    Services_Amount__c                            33338 non-null float64
    Services_Attached__c                          33338 non-null bool
    Stage__c                                      33338 non-null object
    Subscr_Fields_Not_Populated__c                33338 non-null float64
    Subscription_Amount__c                        33338 non-null float64
    Total_List_Price__c                           33338 non-null float64
    Who_is_leading_the_sale__c                    3554 non-null object
    Amount                                        31845 non-null float64
    StageName                                     33338 non-null object
    Type                                          32928 non-null object
    dtypes: bool(14), float64(17), object(27)
    memory usage: 11.6+ MB



    None



```python
raw_data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ACV__c</th>
      <th>Consulting_Services_Amount__c</th>
      <th>Decision_Process__c</th>
      <th>Difference_between_Created_and_Modified__c</th>
      <th>DM_Opp_Age__c</th>
      <th>Inbound_Source__c</th>
      <th>Metric_Accept2Close__c</th>
      <th>Metric_Create2Close__c</th>
      <th>New_and_Add_On_Subscription__c</th>
      <th>New_Business_Subscription__c</th>
      <th>Number_of_Products__c</th>
      <th>Opportunity_Contact_Roles__c</th>
      <th>Services_Amount__c</th>
      <th>Subscr_Fields_Not_Populated__c</th>
      <th>Subscription_Amount__c</th>
      <th>Total_List_Price__c</th>
      <th>Amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>3.333800e+04</td>
      <td>3.333800e+04</td>
      <td>0.0</td>
      <td>33338.000000</td>
      <td>33338.000000</td>
      <td>0.0</td>
      <td>33338.000000</td>
      <td>33338.000000</td>
      <td>2.788600e+04</td>
      <td>1.418400e+04</td>
      <td>33338.000000</td>
      <td>26576.000000</td>
      <td>3.333800e+04</td>
      <td>33338.000000</td>
      <td>3.333800e+04</td>
      <td>3.333800e+04</td>
      <td>3.184500e+04</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>5.035573e+04</td>
      <td>1.008869e+04</td>
      <td>NaN</td>
      <td>571.161445</td>
      <td>142.491541</td>
      <td>NaN</td>
      <td>94.941088</td>
      <td>106.490011</td>
      <td>6.022574e+04</td>
      <td>9.608817e+04</td>
      <td>2.342702</td>
      <td>1.280441</td>
      <td>1.109436e+04</td>
      <td>1.791409</td>
      <td>7.347621e+04</td>
      <td>7.296944e+05</td>
      <td>8.884807e+04</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.090373e+05</td>
      <td>5.107865e+04</td>
      <td>NaN</td>
      <td>202.282226</td>
      <td>190.777608</td>
      <td>NaN</td>
      <td>163.021917</td>
      <td>151.084283</td>
      <td>1.166767e+05</td>
      <td>9.849323e+04</td>
      <td>2.356247</td>
      <td>3.240843</td>
      <td>5.226663e+04</td>
      <td>2.382024</td>
      <td>1.805952e+05</td>
      <td>5.646617e+07</td>
      <td>1.986473e+05</td>
    </tr>
    <tr>
      <th>min</th>
      <td>-3.250000e+05</td>
      <td>-2.040300e+05</td>
      <td>NaN</td>
      <td>53.809074</td>
      <td>-1183.000000</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-3.250000e+05</td>
      <td>-1.791476e+05</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-2.040300e+05</td>
      <td>0.000000</td>
      <td>-3.250000e+05</td>
      <td>-1.190000e+04</td>
      <td>-3.250000e+05</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>NaN</td>
      <td>410.198252</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>0.000000e+00</td>
      <td>2.990000e+02</td>
      <td>2.990000e+02</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>NaN</td>
      <td>545.991250</td>
      <td>70.000000</td>
      <td>NaN</td>
      <td>6.000000</td>
      <td>23.000000</td>
      <td>9.150000e+00</td>
      <td>7.887700e+04</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000e+00</td>
      <td>1.000000</td>
      <td>1.812678e+04</td>
      <td>7.220000e+04</td>
      <td>4.270350e+04</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.887700e+04</td>
      <td>0.000000e+00</td>
      <td>NaN</td>
      <td>744.147477</td>
      <td>253.000000</td>
      <td>NaN</td>
      <td>135.000000</td>
      <td>174.000000</td>
      <td>8.051989e+04</td>
      <td>1.536770e+05</td>
      <td>3.000000</td>
      <td>1.000000</td>
      <td>0.000000e+00</td>
      <td>3.000000</td>
      <td>1.000000e+05</td>
      <td>1.514570e+05</td>
      <td>1.206370e+05</td>
    </tr>
    <tr>
      <th>max</th>
      <td>6.601738e+06</td>
      <td>3.118588e+06</td>
      <td>NaN</td>
      <td>1006.800787</td>
      <td>1829.000000</td>
      <td>NaN</td>
      <td>1855.000000</td>
      <td>1829.000000</td>
      <td>6.601738e+06</td>
      <td>2.000000e+06</td>
      <td>30.000000</td>
      <td>148.000000</td>
      <td>3.214212e+06</td>
      <td>28.000000</td>
      <td>1.155000e+07</td>
      <td>5.595040e+09</td>
      <td>1.155000e+07</td>
    </tr>
  </tbody>
</table>
</div>




```python
raw_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Account_Region__c</th>
      <th>Account_Theater__c</th>
      <th>ACV__c</th>
      <th>C_Contact_has_accepted_a_follow_on_step__c</th>
      <th>Consulting_Services_Amount__c</th>
      <th>Created_by_Role__c</th>
      <th>Deal_Type__c</th>
      <th>Decision_Process__c</th>
      <th>Delivery_Type__c</th>
      <th>Deployment_timeframe__c</th>
      <th>...</th>
      <th>Services_Amount__c</th>
      <th>Services_Attached__c</th>
      <th>Stage__c</th>
      <th>Subscr_Fields_Not_Populated__c</th>
      <th>Subscription_Amount__c</th>
      <th>Total_List_Price__c</th>
      <th>Who_is_leading_the_sale__c</th>
      <th>Amount</th>
      <th>StageName</th>
      <th>Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>North</td>
      <td>NaN</td>
      <td>78877.0</td>
      <td>True</td>
      <td>0.0</td>
      <td>NA-ADR-North-RSM</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>0.0</td>
      <td>False</td>
      <td>Closed Lost</td>
      <td>1.0</td>
      <td>78877.0</td>
      <td>83057.0</td>
      <td>NaN</td>
      <td>78877.0</td>
      <td>Closed Lost</td>
      <td>New Business</td>
    </tr>
    <tr>
      <th>1</th>
      <td>North</td>
      <td>NaN</td>
      <td>114498.0</td>
      <td>False</td>
      <td>0.0</td>
      <td>NA-Channel-GSI Director</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>0.0</td>
      <td>False</td>
      <td>0. Sales Qualified Lead</td>
      <td>2.0</td>
      <td>114498.0</td>
      <td>114498.0</td>
      <td>Partner</td>
      <td>114498.0</td>
      <td>0. Sales Qualified Lead</td>
      <td>New Business</td>
    </tr>
    <tr>
      <th>2</th>
      <td>North</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>False</td>
      <td>0.0</td>
      <td>NA-ADR-North-RSM</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>0.0</td>
      <td>False</td>
      <td>Closed Lost</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>Closed Lost</td>
      <td>New Business</td>
    </tr>
    <tr>
      <th>3</th>
      <td>North</td>
      <td>NaN</td>
      <td>78877.0</td>
      <td>True</td>
      <td>0.0</td>
      <td>EMEA-ADR-UK-RMT</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>0.0</td>
      <td>False</td>
      <td>Closed Lost</td>
      <td>1.0</td>
      <td>78877.0</td>
      <td>83057.0</td>
      <td>NaN</td>
      <td>78877.0</td>
      <td>Closed Lost</td>
      <td>New Business</td>
    </tr>
    <tr>
      <th>4</th>
      <td>UK</td>
      <td>EMEA</td>
      <td>113400.0</td>
      <td>True</td>
      <td>50000.0</td>
      <td>EMEA-Sales-UK-PS-Strategic</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>50000.0</td>
      <td>True</td>
      <td>Closed Lost</td>
      <td>1.0</td>
      <td>113400.0</td>
      <td>193400.0</td>
      <td>MuleSoft</td>
      <td>163400.0</td>
      <td>Closed Lost</td>
      <td>New Business</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 58 columns</p>
</div>



### Exploratory Visualization

**Data types**


```python
import seaborn as sns
import matplotlib.pyplot as plt
%matplotlib inline
import numpy as np

data_types = raw_data.columns.to_series().groupby(raw_data.dtypes).groups
data_types_list = []

for t in data_types:
    data_types_list.append([str(t), len(data_types[t])])

data_types = pd.DataFrame(data_types_list, columns=['Data type','Count'])
data_types.plot(x='Data type', y='Count', kind='barh')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x10ea2ccf8>




![png](output_14_1.png)


**Null values**


```python
null_value_counts = []
for col in raw_data:
    null_value_counts.append((col, raw_data[col].isnull().sum()))
pd.DataFrame(null_value_counts, columns=['Column', 'NullValueCount']).plot(x='Column', y='NullValueCount', kind='barh', figsize=(5,15))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x106f221d0>




![png](output_16_1.png)


**Categorical features with high dimensionality**


```python
high_dimension_categorical_features = []
for index, dtype in enumerate(raw_data.dtypes):
    col = raw_data.columns[index]
    if dtype == 'object':
        unique_value_count = len(raw_data[col].unique())
        # The magic number here is 18 since that is the number of stages         
        if unique_value_count > 18:
            high_dimension_categorical_features.append((col, unique_value_count))

high_dimension_categorical_features = pd.DataFrame(high_dimension_categorical_features, columns=['Column', 'UniqueValueCount'])
display(high_dimension_categorical_features)
high_dimension_categorical_features.plot.barh(x='Column',y='UniqueValueCount')
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column</th>
      <th>UniqueValueCount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Account_Region__c</td>
      <td>22</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Created_by_Role__c</td>
      <td>183</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Lead_Passed_By_Name__c</td>
      <td>352</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Lead_Passed_By_Role__c</td>
      <td>211</td>
    </tr>
    <tr>
      <th>4</th>
      <td>LeadSource</td>
      <td>48</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Lead_Source_Asset__c</td>
      <td>819</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Lead_Source_Detail__c</td>
      <td>207</td>
    </tr>
  </tbody>
</table>
</div>





    <matplotlib.axes._subplots.AxesSubplot at 0x10ec403c8>




![png](output_18_2.png)


This tells that we need to reduce the dimensionality of these features using some kind of unsupervised clustering step like `sklearn.cluster.FeatureAgglomeration`

**Labels**


```python
pd.value_counts(raw_data['StageName']).plot.bar()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x106f022b0>




![png](output_21_1.png)



```python
pd.value_counts(raw_data['Stage__c']).plot.bar()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x10ed6efd0>




![png](output_22_1.png)



```python
pd.value_counts(raw_data['DM_Close_Type__c']).plot.bar()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x10ee20048>




![png](output_23_1.png)



```python
pd.value_counts(raw_data['IsWon']).plot.bar()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x10ef418d0>




![png](output_24_1.png)


This tells that there are multiple features that could be used as our labels but only one is required. Care should be taken to use one properly and remove the others.

E.g. remove samples with `DM_Close_Type__c='Open'`, use the `IsWon` feature as our labels, drop columns closely correlated with this.

**Correlations**


```python
print(high_dimension_categorical_features['Column'])
```

    0         Account_Region__c
    1        Created_by_Role__c
    2    Lead_Passed_By_Name__c
    3    Lead_Passed_By_Role__c
    4                LeadSource
    5      Lead_Source_Asset__c
    6     Lead_Source_Detail__c
    Name: Column, dtype: object



```python
import utils

# drop high dimensional features so we don't blow up the dataset
corr_data = raw_data.drop(high_dimension_categorical_features['Column'].values, axis='columns')
# drop columns with 90% null values
row_count, col_count = corr_data.shape
na_threshold = int(round(row_count * 0.9))
corr_data = corr_data.dropna(thresh=na_threshold, axis='columns')
display(corr_data.shape)
# backfill the remaining null values
corr_data = corr_data.fillna(method='backfill', axis='columns')
# one hot encoding
encoded_corr_data = utils.encode(corr_data)
display(encoded_corr_data.shape)
```


    (33338, 37)



    (33338, 141)



```python
# only run correlation analysis on a sample of the dataset to save time
row_count = encoded_corr_data.shape[0]
encoded_corr_data = encoded_corr_data.sample(int(row_count * 0.1)).dropna(axis='columns')
```


```python
display(encoded_corr_data.shape)
corr = encoded_corr_data.corr().abs()
```


    (3333, 140)



```python
# Generate a mask for the upper triangle
mask = np.zeros_like(corr, dtype=np.bool)
mask[np.triu_indices_from(mask)] = True

# Set up the matplotlib figure
f, ax = plt.subplots(figsize=(11, 9))

# Generate a custom diverging colormap
cmap = sns.diverging_palette(220, 10, as_cmap=True)

# Draw the heatmap with the mask and correct aspect ratio
sns.heatmap(corr, mask=mask, cmap=cmap, vmax=.3, center=0,
            square=True, linewidths=.5, cbar_kws={"shrink": .5})
```




    <matplotlib.axes._subplots.AxesSubplot at 0x10f0cdba8>




![png](output_31_1.png)


This shows there are indeed highly correlated features, but it's hard to tell from this chart which is which. A cursory look hints that the high correlations look predominantly like proxies for our labels. Let's zoom in on that...


```python
is_won = encoded_corr_data['IsWon']
corr_with = encoded_corr_data.corrwith(is_won, axis=0)
corr_with.abs()[corr_with > 0.5].plot(kind='barh', figsize=(5,15))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x11016b080>




![png](output_33_1.png)


This shows the columns most highly correlated with our label column - these features should be removed.

### Algorithms and Techniques

**Constants**


```python
# Set up some necessary constants
SPLIT_RANDOM_SEED = 42
SEARCH_RANDOM_SEED = 56
DCLF_RANDOM_SEED = 42
K_FOLD_RANDOM_SEED = 3
K_FOLDS = 50
K_FEATURES = 50
NA_THRESHOLD = 0.975
LABEL_COLUMN = 'IsWon'
TEST_SIZE = 0.2
```

**Classifiers**


```python
# Set up the dummy classifier for Benchmarking
from sklearn.dummy import DummyClassifier

# Real classifiers for model selection
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
import lightgbm as lgb
import xgboost as xgb
import warnings
warnings.filterwarnings('ignore')
import utils

```

    /usr/local/lib/python3.6/site-packages/lightgbm/__init__.py:46: UserWarning: Starting from version 2.2.1, the library file in distribution wheels for macOS is built by the Apple Clang (Xcode_9.4.1) compiler.
    This means that in case of installing LightGBM from PyPI via the ``pip install lightgbm`` command, you don't need to install the gcc compiler anymore.
    Instead of that, you need to install the OpenMP library, which is required for running LightGBM on the system with the Apple Clang compiler.
    You can install the OpenMP library by the following command: ``brew install libomp``.
      "You can install the OpenMP library by the following command: ``brew install libomp``.", UserWarning)


**Processing utilities**


```python
from sklearn.feature_extraction import DictVectorizer
from sklearn.preprocessing import LabelEncoder, MaxAbsScaler
from sklearn.feature_selection import SelectKBest, mutual_info_classif
from sklearn.cluster import FeatureAgglomeration

# Plus, we want the sklearn model selection tools for cross validation,
# grid search and splitting traingin and testing data.
from sklearn import model_selection
```

All classifiers will go through model selection using default parameters. This should be enough to endicate which is the more performant model. The most performant model will then have it's parameters tuned using `model_selection.GridSearchCV`.

### Benchmark


```python
# Filter down the raw data to only include samples from opportunities that
# are won or lost
print('Raw data shape: ', raw_data.shape)
display(raw_data['DM_Close_Type__c'].unique())
benchmark_data = raw_data[raw_data['DM_Close_Type__c'].isin(['Lost','Won'])]
print('Benchmark data shape: ', benchmark_data.shape)
display(benchmark_data['DM_Close_Type__c'].unique())
display(benchmark_data['StageName'].unique())
```

    Raw data shape:  (33338, 58)



    array(['Lost', 'Open', 'Won'], dtype=object)


    Benchmark data shape:  (30339, 58)



    array(['Lost', 'Won'], dtype=object)



    array(['Closed Lost', 'Rejected Lead', 'Closed Won'], dtype=object)



```python
# Pull our labels out from the benchmark data and encode them
labels = np.asarray(benchmark_data[LABEL_COLUMN])
labels = LabelEncoder().fit_transform(labels)
benchmark_data = benchmark_data.drop([LABEL_COLUMN], axis='columns')
print('Benchmark data shape: ', benchmark_data.shape)
```

    Benchmark data shape:  (30339, 57)



```python
# First pass at dropping na columns
row_count, col_count = benchmark_data.shape
na_thresh = int(round(row_count * NA_THRESHOLD))
benchmark_data = benchmark_data.dropna(thresh=na_thresh, axis='columns')
print('Benchmark data shape: ', benchmark_data.shape)
```

    Benchmark data shape:  (30339, 34)



```python
# Backfill the remaining columns
benchmark_data = benchmark_data.fillna(method='backfill', axis='columns')
```


```python
# Deal with high dimensional features:
# - remove them from benchmark_data to new DataFrame
# - one hot encode both DataFrames
# - perform feature agglomeration on the high dimensional features
# - join the Dataframes together again
high_dimension_categorical_feature_names = []
for index, dtype in enumerate(benchmark_data.dtypes):
    col = benchmark_data.columns[index]
    if dtype == 'object':
        unique_value_count = len(benchmark_data[col].unique())
        # The magic number here is 18 since that is the number of stages         
        if unique_value_count > 18:
            high_dimension_categorical_feature_names.append(col)
high_dimension_categorical_features = benchmark_data[high_dimension_categorical_feature_names]
benchmark_data = benchmark_data.drop(high_dimension_categorical_feature_names, axis='columns')
print('High dimensional data shape: ', high_dimension_categorical_features.shape)
print('Benchmark data shape: ', benchmark_data.shape)
```

    High dimensional data shape:  (30339, 14)
    Benchmark data shape:  (30339, 20)



```python
# Encode and agglomerate high dimensional features
high_dimension_categorical_features = utils.encode(high_dimension_categorical_features)
print('High dimensional data shape: ', high_dimension_categorical_features.shape)
high_dimension_categorical_features = FeatureAgglomeration(n_clusters=32).fit_transform(high_dimension_categorical_features)
print('High dimensional data shape: ', high_dimension_categorical_features.shape)

# Encode the rest of the data
benchmark_data = utils.encode(benchmark_data)
print('Benchmark data shape: ', benchmark_data.shape)
```

    High dimensional data shape:  (30339, 202)
    High dimensional data shape:  (30339, 32)
    Benchmark data shape:  (30339, 40)



```python
# Deal with correlated features
labels_df = pd.DataFrame(labels, columns=['label'], dtype='float64')
benchmark_corr = benchmark_data.corr()

# Generate a mask for the upper triangle
mask = np.zeros_like(benchmark_corr, dtype=np.bool)
mask[np.triu_indices_from(mask)] = True

# Set up the matplotlib figure
f, ax = plt.subplots(figsize=(11, 9))

# Generate a custom diverging colormap
cmap = sns.diverging_palette(220, 10, as_cmap=True)

# Draw the heatmap with the mask and correct aspect ratio
sns.heatmap(benchmark_corr, mask=mask, cmap=cmap, vmax=.3, center=0,
            square=True, linewidths=.5, cbar_kws={"shrink": .5})
```




    <matplotlib.axes._subplots.AxesSubplot at 0x10be10c50>




![png](output_50_1.png)



```python
corr_df = benchmark_data
corr_df['label'] = labels

corr = corr_df.corr()

# Generate a mask for the upper triangle
mask = np.zeros_like(corr, dtype=np.bool)
mask[np.triu_indices_from(mask)] = True

# Set up the matplotlib figure
f, ax = plt.subplots(figsize=(11, 9))

# Generate a custom diverging colormap
cmap = sns.diverging_palette(220, 10, as_cmap=True)

# Draw the heatmap with the mask and correct aspect ratio
sns.heatmap(corr, mask=mask, cmap=cmap, vmax=.3, center=0,
            square=True, linewidths=.5, cbar_kws={"shrink": .5})
```




    <matplotlib.axes._subplots.AxesSubplot at 0x10fc54ba8>




![png](output_51_1.png)



```python
corr['label'].abs()[corr['label'].abs() > 0.5].plot(kind='barh')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x10f0be400>




![png](output_52_1.png)



```python
# drop the correlated columns from the benchmark data
cols_to_drop = list(corr['label'].abs()[corr['label'].abs() > 0.5].drop(labels=['label']).keys())
benchmark_data = benchmark_data.drop(columns=cols_to_drop)
print('Benchmark data shape: ', benchmark_data.shape)
```

    Benchmark data shape:  (30339, 32)



```python
benchmark_data = benchmark_data.dropna(axis='columns')
```


```python
# join high dimensional data and rest of benchmark data
benchmark_array = np.hstack((np.asarray(benchmark_data), high_dimension_categorical_features))

print('High dimensional data shape: ', high_dimension_categorical_features.shape)
print('Benchmark data shape: ', benchmark_data.shape)
print('Benchmark array shape: ', benchmark_array.shape)
```

    High dimensional data shape:  (30339, 32)
    Benchmark data shape:  (30339, 31)
    Benchmark array shape:  (30339, 63)



```python
# train test split
X_train, X_test, y_train, y_test = model_selection.train_test_split(benchmark_array, labels, test_size=TEST_SIZE, random_state=SPLIT_RANDOM_SEED)
```


```python
dclf = DummyClassifier(random_state=DCLF_RANDOM_SEED)
```


```python
# CV the dummy classifier and report the mean f1_score
kfold = model_selection.KFold(n_splits=K_FOLDS, random_state=K_FOLD_RANDOM_SEED)
cv_results = model_selection.cross_val_score(dclf, X_train, y_train, cv=kfold, scoring=f1_scorer)
display('Mean f1_score from KFold cross validation {:0.2f}'.format(cv_results.mean()))
```


    'Mean f1_score from KFold cross validation 0.56'


## 3. Methodolgy

### Data Preprocessing


```python
# Load the dataset
raw = pd.read_csv('data/csv/raw_data.csv', low_memory=False)
print('Raw data shape: ', raw.shape)
```

    Raw data shape:  (33338, 58)



```python
# Filter down the raw data to only include samples from opportunities that
# are won or lost
df = raw[raw['DM_Close_Type__c'].isin(['Lost','Won'])]
print('df shape: ', df.shape)
```

    df shape:  (30339, 58)



```python
# Pull our labels out from the benchmark data and encode them
labels = np.asarray(df[LABEL_COLUMN])
labels = LabelEncoder().fit_transform(labels)
df = df.drop([LABEL_COLUMN], axis='columns')
print('df shape: ', df.shape)
print('labels shape: ', labels.shape)
```

    df shape:  (30339, 57)
    labels shape:  (30339,)



```python
# First pass at dropping na columns
row_count, col_count = df.shape
na_thresh = int(round(row_count * NA_THRESHOLD))
df = df.dropna(thresh=na_thresh, axis='columns')
print('df shape: ', df.shape)
```

    df shape:  (30339, 34)



```python
# Backfill the remaining columns
df = df.fillna(method='backfill', axis='columns')
```


```python
# Pick out high dimensional features 
hd_feature_names = []
for index, dtype in enumerate(df.dtypes):
    col = df.columns[index]
    if dtype == 'object':
        unique_value_count = len(df[col].unique())
        # The magic number here is 18 since that is the number of stages         
        if unique_value_count > 18:
            hd_feature_names.append(col)
hd_features = df[hd_feature_names]
df = df.drop(hd_feature_names, axis='columns')
print('High dimensional data shape: ', hd_features.shape)
print('df shape: ', df.shape)
```

    High dimensional data shape:  (30339, 14)
    df shape:  (30339, 20)



```python
# Encode and agglomerate high dimensional features
hd_features = utils.encode(hd_features)
hd_features = FeatureAgglomeration(n_clusters=32).fit_transform(hd_features)

# Encode the rest of the data
df = utils.encode(df)

print('High dimensional data shape: ', hd_features.shape)                           
print('df shape: ', df.shape)
```

    High dimensional data shape:  (30339, 32)
    df shape:  (30339, 40)



```python
# Remove highly correlated features with label
corr_df = df.copy(deep=True)
corr_df['label'] = labels

corr = corr_df.corr()
corr['label'].abs()[corr['label'].abs() > 0.5].plot(kind='barh')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x10ffe52e8>




![png](output_68_1.png)



```python
cols_to_drop = list(corr['label'].abs()[corr['label'].abs() > 0.5].drop(labels=['label']).keys())
df = df.drop(columns=cols_to_drop)
print('df shape: ', df.shape)
```

    df shape:  (30339, 31)



```python
# Final drop of null columns
df = df.dropna(axis='columns')
```


```python
# Prep features array
features = np.hstack((np.asarray(df), hd_features))

print('High dimensional data shape: ', hd_features.shape)
print('df shape: ', df.shape)
print('Features array shape: ', features.shape)
print('Labels array shape: ', labels.shape)
```

    High dimensional data shape:  (30339, 32)
    df shape:  (30339, 30)
    Features array shape:  (30339, 62)
    Labels array shape:  (30339,)



```python
# train test split
X_train, X_test, y_train, y_test = model_selection.train_test_split(features, labels, test_size=TEST_SIZE, random_state=SPLIT_RANDOM_SEED)
```

### Implementation


```python
# Set up our data structure of models
models = []
models.append(('LR', LogisticRegression()))
models.append(('NB', GaussianNB()))
models.append(('RF', RandomForestClassifier()))
models.append(('LGBM', lgb.sklearn.LGBMClassifier(objective='binary')))
models.append(('XGB', xgb.XGBClassifier(objective='binary:logistic')))
```


```python
# Model Evaluation via cross validation
results = []
names = []

X = features.copy()
y = labels.copy()
X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, test_size=TEST_SIZE, random_state=SPLIT_RANDOM_SEED)

for name, model in models:
    kfold = model_selection.StratifiedKFold(n_splits=K_FOLDS, shuffle=True, random_state=K_FOLD_RANDOM_SEED)
    cv_results = model_selection.cross_val_score(model, X_train, y_train, cv=kfold, scoring=f1_scorer)
    results.append(cv_results)
    names.append(name)
    msg = "%s: %f (%f)" % (name, cv_results.mean(), cv_results.std())
    print(msg)

# Boxplot to compare algorithms
fig = plt.figure()
fig.suptitle('Comparison of Classifiers')
ax = fig.add_subplot(111)
plt.boxplot(results)
ax.set_xticklabels(names)
plt.show()
```

    LR: 0.802138 (0.110129)
    NB: 0.720277 (0.001949)
    RF: 0.952648 (0.010811)
    LGBM: 0.962710 (0.009271)
    XGB: 0.958668 (0.010180)



![png](output_75_1.png)


### Refinement


```python
X = features.copy()
y = labels.copy()
X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, test_size=TEST_SIZE, random_state=SPLIT_RANDOM_SEED)

# Feature scaling
X_train = MaxAbsScaler().fit_transform(X_train)
X_test = MaxAbsScaler().fit_transform(X_test)
```


```python
# Feature selection
X_train = SelectKBest(score_func=mutual_info_classif, k=K_FEATURES).fit_transform(X_train, y_train)
X_test = SelectKBest(score_func=mutual_info_classif, k=K_FEATURES).fit_transform(X_test, y_test)
```


```python
# Set up our data structure of models
models = []
models.append(('LR', LogisticRegression()))
models.append(('NB', GaussianNB()))
models.append(('RF', RandomForestClassifier()))
models.append(('LGBM', lgb.sklearn.LGBMClassifier(objective='binary')))
models.append(('XGB', xgb.XGBClassifier(objective='binary:logistic')))
```


```python
# Model Evaluation via cross validation
results = []
names = []

for name, model in models:
    kfold = model_selection.KFold(n_splits=K_FOLDS, shuffle=True, random_state=K_FOLD_RANDOM_SEED)
    cv_results = model_selection.cross_val_score(model, X_train, y_train, cv=kfold, scoring=f1_scorer)
    results.append(cv_results)
    names.append(name)
    msg = "%s: %f (%f)" % (name, cv_results.mean(), cv_results.std())
    print(msg)

# Boxplot to compare algorithms
fig = plt.figure()
fig.suptitle('Comparison of Classifiers')
ax = fig.add_subplot(111)
plt.boxplot(results)
ax.set_xticklabels(names)
plt.show()
```

    LR: 0.933005 (0.010656)
    NB: 0.913139 (0.011102)
    RF: 0.954264 (0.008907)
    LGBM: 0.962676 (0.008479)
    XGB: 0.958288 (0.009226)



![png](output_80_1.png)



```python
X = features.copy()
y = labels.copy()
X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, test_size=TEST_SIZE, random_state=SPLIT_RANDOM_SEED)
```


```python
# Set up our data structure of models
models = []
models.append(('LR', LogisticRegression()))
models.append(('NB', GaussianNB()))
models.append(('RF', RandomForestClassifier()))
models.append(('LGBM', lgb.sklearn.LGBMClassifier(objective='binary')))
models.append(('XGB', xgb.XGBClassifier(objective='binary:logistic')))

scores = []

for name, model in models:
    clf = model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    score = f1_score(y_test, y_pred)
    scores.append((name, score))

for name, score in scores:
    print(name, score)
```

    LR 0.871687587169
    NB 0.718105908466
    RF 0.956534594914
    LGBM 0.964536928488
    XGB 0.959612277868



```python
grid_params = {
    'LR': {
        'C': np.logspace(-3,3,7),
        'penalty': ['l1', 'l2']
    },
    'LGBM': {
        'learning_rate': [0.1, 0.01, 0.005],
        'num_leaves': [6,8,12,16],
        'n_estimators': [50,100,200],
        'objective' : ['binary'],
        'random_state': [42]
    }
}

# Set up our data structure of models
models = []
models.append(('LR', LogisticRegression()))
models.append(('LGBM', lgb.sklearn.LGBMClassifier(objective='binary')))

scores = []

X = features.copy()
y = labels.copy()
X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, test_size=TEST_SIZE, random_state=SPLIT_RANDOM_SEED)

for name, model in models:
    n_jobs = 4
    if name == 'LR':
        n_jobs = 1
    clf = model_selection.GridSearchCV(model, grid_params[name], verbose=0, cv=kfold, n_jobs=1, scoring=f1_scorer)
    clf = clf.fit(X_train, y_train)
    score = clf.best_score_
    scores.append((name, score))       
       
for name, score in scores:
    print(name, score)
```

    LR 0.939812380966
    LGBM 0.962049929935


## 4. Results

### Model Evaluation and Validation

### Jusitifcation

## 5. Conclusion

### Free-Form Visualization

### Reflection

### Improvement
